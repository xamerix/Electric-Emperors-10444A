/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\bit2s                                            */
/*    Created:      Fri Jan 06 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

float flywheelVolt = 7.3; // setting default flywheel velocity 
 void shortrange() {
   flywheelVolt = 9;
 }
 void longrange() // defining function
{
  flywheelVolt = 10; // increase velo by 25%
 
}
void midrange()
{
  flywheelVolt = 8.4;
  }
  
/*
double kP = 1; // tuning values
//double kI = 3200; //
double kD = 1; //
double turnkP = 0.1; // 
//double turnkI = 0.1; //
double turnkD = 0.1; //
// default auton settings
int leftdesiredValue = 360;
int rightdesiredValue = 360;
int desiredTurnValue = 0;
// setting variables
int lefterror; // Motor value - desired value :: position
int righterror;
int leftprevError = 0; // previous position 20 ms ago 
int rightprevError = 0;
int rightderivative; // error-prevError :: speed
int leftderivative;
int totalError = 0; // total error = totalError + error
int turnError;
int turnprevError;
int turnDerivative;
int turnTotalError;

bool resetDriveSensor = false;
// enable PID
bool enablePID = true;
//
int autoPID() {
  while (enablePID) {
    if (resetDriveSensor) {
      Motor1.setPosition(0,degrees);
      Motor2.setPosition(0,degrees);
      Motor3.setPosition(0,degrees);
      Motor4.setPosition(0,degrees);
      Motor5.setPosition(0,degrees);
      Motor6.setPosition(0,degrees);
      resetDriveSensor = false;
    }
    
    int motor1Value = Motor1.position(degrees); // motor pos 
    int motor2Value = Motor2.position(degrees);
    int motor3Value = Motor3.position(degrees);
    int motor4Value = Motor4.position(degrees);
    int motor5Value = Motor5.position(degrees);
    int motor6Value = Motor6.position(degrees);
    int leftMotorValue = (motor1Value + motor2Value + motor3Value)/3; // for multiple motors, get average pos
    int rightMotorValue = (motor4Value + motor5Value + motor6Value)/3;
    //////////////////////////////////////////////
    //LATERAL MOVEMENT 
    //////////////////////////////////////////////
    lefterror = leftdesiredValue - leftMotorValue ;
    righterror = rightdesiredValue - rightMotorValue ;
    //
    leftderivative = lefterror - leftprevError;
    rightderivative = righterror - rightprevError;

    //
    //totalError += error; // Velo -> Pos -> Absement (pos*time)

    //
    double rightpower = (righterror*kP + rightderivative * kD)/12.0; // 12 for voltage, 360 for degrees
    double leftpower = (lefterror*kP + leftderivative *kD)/12.0;
    
    
    //////////////////////////////////////////////
    //TURNING 
    //////////////////////////////////////////////
    int turnDifference = (motorValue)/1; // left-right
    turnError = desiredValue - turnDifference;
    //
    turnDerivative = turnError - turnprevError;
    //
    //totalError += turnError; // Velo -> Pos -> Absement (pos*time)

    //
    double turnPower = (turnError*turnkP + turnDerivative * turnkD)/12.0; // 12 for voltage, 360 for degrees
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////


    Motor1.spin(forward, leftpower, volt);
    Motor2.spin(forward, leftpower, volt);
    Motor3.spin(forward, leftpower, volt);
    Motor4.spin(forward, rightpower, volt);
    Motor5.spin(forward, rightpower, volt);
    Motor6.spin(forward, rightpower, volt);
    leftprevError = lefterror; // sets prevError
    rightprevError = righterror;
    vex::task::sleep(20); //refresh
  }

  // NO INTEGRAL FOR DRIVETRAIN, BECAUSE OF OSCILLATION, do a PD controller
 return 1;
} 
*/
int turnAt = 180;
void turn1() {
  Motor1.startSpinFor(-turnAt, degrees);
  Motor2.startSpinFor(-turnAt, degrees);
  Motor3.startSpinFor(turnAt, degrees);

  Motor4.startSpinFor(-turnAt, degrees);
  Motor5.startSpinFor(turnAt, degrees);
  Motor6.spinFor(-turnAt, degrees);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  //bool buttonUpRegistered = false;
  //bool buttonDownRegistered =afalse;
  const int wheelTravel = 320;
  const int trackWidth = 320;
  const int wheelBase = 130;
  motor_group driveL(Motor1, Motor2, Motor3);
  motor_group driveR(Motor4, Motor5, Motor6);
  

  drivetrain myDrivetrain(driveL, driveR, wheelTravel, trackWidth, wheelBase, mm);
  // setting drivetrain things
  //endgame
  Controller1.ButtonUp.pressed(longrange); // if the up button is pressed, it increases velocity
  Controller1.ButtonLeft.pressed(midrange);
  Controller1.ButtonDown.pressed(shortrange); // if the down button is pressed, it decreases velocity
  while (1)  { // user control goes here
          if (Controller1.ButtonB.pressing()) {
            if (Controller1.ButtonRight.pressing()) { // 2 buttons have to be held
              Cata.set(true); // setting digi_out Cata (piston) to extended
          } else { // if the sequence isn't pressed the piston stays retracted
              Cata.set(false);
          }
          }
      
  

      if (Controller1.ButtonL2.pressing()) {
              Indexer.set(false); // same thing as the cata except flipped (it starts extended)
      } else  {
              Indexer.set(true);
          }


  
      
        if (Controller1.ButtonR1.pressing() == true) {
          intake.spin(vex::directionType::rev, 10.2, volt); // spins the intake in reverse, at 500 rpm
        }
        else if (Controller1.ButtonL1.pressing() == true) { 
          intake.spin(vex::directionType::fwd, 10.2, volt); 
        }
        else if (flywheel.isSpinning()) {
          intake.spin(vex::directionType::rev, 7.5, volt);
        }
        else  {
          intake.stop(brakeType::brake);
        }
    



   Motor1.spin(fwd, 12*(Controller1.Axis2.value()*0.6)/100,volt);
   Motor2.spin(fwd, 12*(Controller1.Axis2.value()* 0.6)/100, volt);
   Motor3.spin(fwd, 12*(Controller1.Axis2.value()*0.6)/100,volt);
   Motor4.spin(vex::directionType::fwd, 12*(Controller1.Axis3.value()*0.6)/100,volt);
   Motor5.spin(vex::directionType::fwd, 12*(Controller1.Axis3.value()*0.6)/100,volt); 
   Motor6.spin(vex::directionType::fwd, 12*(Controller1.Axis3.value()*0.6)/100,volt); 
 
   // spins motor       fwd or rev     takes axis value      +/- other axis value           the value in pct is the velo
   
  

   

      

     
      
          
          if (Controller1.ButtonR2.pressing() == true) {

            flywheel.spin(vex::directionType::fwd, 7.8, vex::voltageUnits::volt);

          }
          
         
          
          
            
          if (Controller1.ButtonR2.pressing() == false) {
            flywheel.stop(hold); // if the button isnt being pressed it stops the flywheel
          }
          vex::task::sleep(20);
        } 

        
}
        
            

      
          
      


