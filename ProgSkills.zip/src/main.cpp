/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Arnav Patil                                      */
/*    Created:      Sat Jan 14 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Motor1               motor         1               
// Controller1          controller                    
// Inertial8            inertial      8               
// ---- END VEXCODE CONFIGURED DEVICES ----
// https://youtu.be/_Itn-0d340g
#include "vex.h"
using namespace vex;
// settings
double kP = 0.2; // tuning values
//double kI = 3200; //
double kD = 0.2; //
double turnkP = 0.6; // 
//double inertialkI = 0.1; //
double turnkD = 0.2; //
// default auton settings
int desiredValue = 0;
int desiredTurnValue = 0;
// setting variables
int error; // Motor value - desired value :: position
int prevError = 0; // previous position 20 ms ago 
int derivative; // error-prevError :: speed
int totalError = 0; // total error = totalError + error
double turnError;
int turnprevError = 0;
int turnDerivative;
//int inertialTotalError = 0;
double intertialValue; 
bool resetDriveSensor = false;
bool resetInertial = false;
//bool inertialCorrection = true;
// enable PID
bool enablePID = true;
//
motor_group LeftMotors(Motor1,Motor2,Motor3);
motor_group RightMotors(Motor4, Motor5, Motor6);
drivetrain myDrivetrain(LeftMotors, RightMotors);
int autoPID() {
  while (enablePID) {
    while (resetDriveSensor) {
      resetDriveSensor = false;
      
      Motor1.setPosition(0,degrees);
      Motor2.setPosition(0,degrees);
      Motor3.setPosition(0,degrees);
      Motor4.setPosition(0,degrees);
      Motor5.setPosition(0,degrees);
      Motor6.setPosition(0,degrees);
    
    
    }
    int leftmotorvalue = LeftMotors.position(degrees);
    int rightmotorvalue = RightMotors.position(degrees);
    int motor1Value = Motor1.position(degrees);
    int motor2Value = Motor2.position(degrees);
    int motor3Value = Motor3.position(degrees);
    int motor4Value = Motor4.position(degrees);
    int motor5Value = Motor5.position(degrees);
    int motor6Value = Motor6.position(degrees);
    int averageValue = (motor1Value+motor2Value+motor3Value+motor4Value+motor5Value+motor6Value)/6;
    //////////////////////////////////////////////
    /* LATERAL MOVEMENT */
    //////////////////////////////////////////////
    error = desiredValue - averageValue;


    derivative = error - prevError;

   
    double power = (error*kP + derivative * kD)/12.0;
    

    ////////////////////////////////////////////
    /* TURNING */
    ///////////////////////////////////////////
    
    int turnDifference = ((motor1Value+motor2Value+motor3Value)-(motor4Value+motor5Value+motor6Value))/6; // left-right
     
    turnError = desiredTurnValue - turnDifference;
     
     
    //
    turnDerivative = turnError - turnprevError;
    double turnPower = (turnError*turnkP + turnDerivative * turnkD)/12.0; // 12 for voltage, 360 for degrees
 
    //
    //totalError += turnError; // Velo -> Pos -> Absement (pos*time)

    //
    
    
    Motor1.spin(forward, power+turnPower , volt);
    Motor2.spin(forward, power+turnPower , volt);
    Motor3.spin(forward, power+turnPower , volt);
    Motor4.spin(forward, power-turnPower , volt);
    Motor5.spin(forward, power-turnPower , volt);
    Motor6.spin(forward, power-turnPower , volt);
    
    prevError = error; 
    turnprevError = turnError;
    vex::task::sleep(20); //refresh
  }
  
 
return 1;

}





  



int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  vex::task autoPid(autoPID);
  //auto
  Indexer.set(true);
  resetDriveSensor = true;
  wait(0.1,sec);
  intake.spin(reverse,9,volt);
  wait(1,sec);
  desiredValue = -160;
  wait(0.1,sec);
  resetDriveSensor = true;
  desiredValue = 190;
  desiredTurnValue=0; // 90 degrees = 180
  wait(1,sec);
  intake.spin(reverse, 9, volt);
  desiredTurnValue = 160;
  desiredValue = 220;
  intake.stop();
  wait(0.4,sec);
  intake.spin(vex::directionType::rev, 9, volt);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  wait(1,sec);
  desiredTurnValue = -220;
  wait(0.3,sec);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  wait(0.6,sec);
  desiredValue = 120;
  desiredTurnValue = 0;
  resetDriveSensor = true;
  desiredValue = 65;
  resetDriveSensor = true;
  wait(0.67,sec);
  desiredTurnValue = -230;
  wait(0.6,sec);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  desiredValue = -480;
  wait(0.1,sec);
  intake.spin(vex::directionType::rev, 9, vex::voltageUnits::volt);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  wait(0.86,sec);
  desiredValue = 40;
  wait(0.1,sec);
  intake.stop();
  wait(0.2,sec);
  flywheel.spin(fwd,9.3,volt);
  desiredTurnValue = 220;
  wait(0.8,sec);
  intake.stop();
  desiredTurnValue = 0;
  resetDriveSensor = true;
  wait(0.4,sec);
  desiredValue = 920;
  desiredTurnValue =0;
  wait(0.2,sec);
  resetDriveSensor = true;
  wait(1.3,sec);
  wait(0.2,sec);
  desiredTurnValue = -24;
  wait(0.2,sec);
  wait(0.1,sec);
  wait(0.2,sec);
  intake.spin(reverse , 7.5, volt);
  wait(2.8,sec);
  wait(0.5,sec);
  Indexer.set(false);
  wait(3.2,sec);
  flywheel.stop();
  intake.stop();
  desiredTurnValue = 0;
  resetDriveSensor = true;
  Indexer.set(true);
  desiredValue = -560;
  wait(0.5,sec);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  wait(1.5,sec);
  desiredTurnValue = -130;
  wait(0.4,sec);
  desiredTurnValue = 0;
  resetDriveSensor = true;
  intake.spin(reverse,9,volt);
  desiredValue = 480;
  wait(0.1,sec);


 

  //continue
  //auto*/
}
