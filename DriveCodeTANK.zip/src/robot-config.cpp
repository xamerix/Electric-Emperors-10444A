#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;
controller Controller1;
digital_out Indexer = digital_out(Brain.ThreeWirePort.D);
digital_out Cata = digital_out(Brain.ThreeWirePort.B);
//digi_out name = type(Brain.ThreeWirePort.Port)
motor Motor1 = motor(PORT5, ratio18_1, false);
motor Motor2 = motor(PORT20, ratio18_1, true);
motor Motor3 = motor(PORT21, ratio18_1, false);
motor Motor4 = motor(PORT10, ratio18_1, true);
motor Motor5 = motor(PORT19, ratio18_1, false);
motor Motor6 = motor(PORT11, ratio18_1, true);
motor intake = motor(PORT1, ratio6_1, false);
motor flywheel = motor(PORT18, ratio6_1, false);
/**
 * Used to initialize code/tasks/devices added using nightools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // Nothing to initialize
}