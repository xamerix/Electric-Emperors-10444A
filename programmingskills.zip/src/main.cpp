/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Arnav Patil                                      */
/*    Created:      Sat Jan 14 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Motor1               motor         1               
// Controller1          controller                    
// Inertial8            inertial      8               
// ---- END VEXCODE CONFIGURED DEVICES ----
// https://youtu.be/_Itn-0d340g
#include "vex.h"
using namespace vex;
// settings
double kP = 0.2; // tuning values
double kD = 0.2; //
double turnkP = 0.6; // 
double turnkD = 0.2; //
// default auton settings
double desiredValue = 0;
double desiredTurnValue = 0;
// setting variables
int error; // Motor value - desired value :: position
int prevError = 0; // previous position 20 ms ago 
int derivative; // error-prevError :: speed
int totalError = 0; // total error = totalError + error
double turnError;
int turnprevError = 0;
int turnDerivative;
bool resetDriveSensor = false;
//bool inertialCorrection = true;
// enable PID
bool enablePID = true;
motor_group LeftMotors(Motor1,Motor2,Motor3);
motor_group RightMotors(Motor4, Motor5, Motor6);

void driveTo() {
  LeftMotors.spinFor(fwd , desiredValue, degrees,false);
  RightMotors.spinFor(fwd,desiredValue,degrees,true);
}
void turnTo() {
  LeftMotors.spinFor(reverse,desiredTurnValue,degrees,false);
  RightMotors.spinFor(fwd,desiredTurnValue,degrees,true);
  
}
void launchDiscs() {
   intake.spin(reverse,7.5,volt);
   wait(0.3,sec);
   intake.spin(reverse,7.5,volt);
   Indexer.set(false);
}
//

drivetrain myDrivetrain(LeftMotors, RightMotors);
int autoPID() {
  while (enablePID) {
    while (resetDriveSensor) {
      resetDriveSensor = false;
      
      Motor1.setPosition(0,degrees);
      Motor2.setPosition(0,degrees);
      Motor3.setPosition(0,degrees);
      Motor4.setPosition(0,degrees);
      Motor5.setPosition(0,degrees);
      Motor6.setPosition(0,degrees);
    
    
    }
    int leftmotorvalue = LeftMotors.position(degrees);
    int rightmotorvalue = RightMotors.position(degrees);
    int motor1Value = Motor1.position(degrees);
    int motor2Value = Motor2.position(degrees);
    int motor3Value = Motor3.position(degrees);
    int motor4Value = Motor4.position(degrees);
    int motor5Value = Motor5.position(degrees);
    int motor6Value = Motor6.position(degrees);
    int averageValue = (motor1Value+motor2Value+motor3Value+motor4Value+motor5Value+motor6Value)/6;
    //////////////////////////////////////////////
    /* LATERAL MOVEMENT */
    //////////////////////////////////////////////
    error = desiredValue - averageValue;


    derivative = error - prevError;

   
    double power = (error*kP + derivative * kD)/12.0;
    

    ////////////////////////////////////////////
    /* TURNING */
    ///////////////////////////////////////////
    
    int turnDifference = ((motor1Value+motor2Value+motor3Value)-(motor4Value+motor5Value+motor6Value))/6; // left-right
     
    turnError = desiredTurnValue - turnDifference;
     
     
    //
    turnDerivative = turnError - turnprevError;
    double turnPower = (turnError*turnkP + turnDerivative * turnkD)/12.0; // 12 for voltage, 360 for degrees
 
    //
    //totalError += turnError; // Velo -> Pos -> Absement (pos*time)

    //
    
    
    Motor1.spin(forward, power+turnPower , volt);
    Motor2.spin(forward, power+turnPower , volt);
    Motor3.spin(forward, power+turnPower , volt);
    Motor4.spin(forward, power-turnPower , volt);
    Motor5.spin(forward, power-turnPower , volt);
    Motor6.spin(forward, power-turnPower , volt);
    
    prevError = error; 
    turnprevError = turnError;
    vex::task::sleep(20); //refresh
  }
  
 
return 1;

}





  



int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  vex::task autoPid(autoPID);
  //auto
  enablePID = false;
  LeftMotors.setVelocity(30, percent);
  RightMotors.setVelocity(30, percent);
  Indexer.set(true);
  intake.spin(fwd,9,volt);
  wait(0.4,sec);
  intake.spin(reverse,9,volt);
  wait(0.5,sec);
  desiredValue = -60;
  driveTo();
  wait(0.1,sec);
  resetDriveSensor = true;
  desiredValue = 120;
  driveTo();
  desiredTurnValue = -130;
  turnTo();
  wait(0.3,sec);
  desiredValue = 240;
  driveTo();
  wait(0.1,sec);
  desiredTurnValue = 130;
  turnTo();
  desiredValue = 280;
  driveTo();
  desiredTurnValue = 180;
  turnTo();
  desiredValue = -320;
  driveTo();
  wait(0.05,sec);
  desiredValue = 120;
  driveTo();
  desiredTurnValue = -180;
  turnTo();
  flywheel.spin(fwd,9.8,volt);
  desiredValue = 960;
  driveTo();
  desiredTurnValue = 8;
  turnTo();
  launchDiscs();
  wait(0.1,sec);
  desiredTurnValue = -8;
  turnTo();
  desiredValue = -740;
  driveTo();

}
